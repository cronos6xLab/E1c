let ubicacionActual = null;
let horaIncidente = null;

const pantallaInicial = document.getElementById('pantallaInicial');
const pantallaCarga = document.getElementById('pantallaCarga');
const pantallaEmergencia = document.getElementById('pantallaEmergencia');
const pantallaHistorial = document.getElementById('pantallaHistorial');

const btnEmergencia = document.getElementById('btnEmergencia');
const btnVolver = document.getElementById('btnVolver');
const btnHistorial = document.getElementById('btnHistorial');
const btnVolverHistorial = document.getElementById('btnVolverHistorial');
const btnLimpiarHistorial = document.getElementById('btnLimpiarHistorial');
const btnWhatsApp = document.getElementById('btnWhatsApp');
const btnSMS = document.getElementById('btnSMS');
const btnEmail = document.getElementById('btnEmail');

function init() {
    btnEmergencia?.addEventListener('click', activarEmergencia);
    btnVolver?.addEventListener('click', () => mostrarPantalla('inicial'));
    btnHistorial?.addEventListener('click', mostrarHistorial);
    btnVolverHistorial?.addEventListener('click', () => mostrarPantalla('emergencia'));
    btnLimpiarHistorial?.addEventListener('click', limpiarHistorial);
    btnWhatsApp?.addEventListener('click', enviarWhatsApp);
    btnSMS?.addEventListener('click', enviarSMS);
    btnEmail?.addEventListener('click', enviarEmail);
    cargarNumerosEmergencia();
}

function mostrarPantalla(pantalla) {
    document.querySelectorAll('.screen')?.forEach(screen => {
        screen?.classList?.remove('active');
    });
    switch(pantalla) {
        case 'inicial':
            pantallaInicial?.classList?.add('active');
            break;
        case 'carga':
            pantallaCarga?.classList?.add('active');
            break;
        case 'emergencia':
            pantallaEmergencia?.classList?.add('active');
            break;
        case 'historial':
            pantallaHistorial?.classList?.add('active');
            break;
    }
}

async function activarEmergencia() {
    try {
        mostrarPantalla('carga');
        horaIncidente = new Date();
        ubicacionActual = await obtenerUbicacion();
        guardarEnHistorial({ fecha: horaIncidente, ubicacion: ubicacionActual });
        mostrarDatosEmergencia();
        mostrarPantalla('emergencia');
    } catch (error) {
        console.error('Error al activar emergencia:', error);
        alert('⚠️ Error al capturar la ubicación. Verifica que hayas dado permisos de ubicación.');
        mostrarPantalla('inicial');
    }
}

function obtenerUbicacion() {
    return new Promise((resolve, reject) => {
        if (!navigator?.geolocation) {
            reject(new Error('Geolocalización no disponible'));
            return;
        }
        navigator.geolocation.getCurrentPosition(
            async (position) => {
                const lat = position?.coords?.latitude ?? 0;
                const lon = position?.coords?.longitude ?? 0;
                const direccion = await obtenerDireccion(lat, lon);
                resolve({
                    latitud: lat,
                    longitud: lon,
                    direccion: direccion,
                    coordenadas: `${lat?.toFixed(6) ?? '0'}, ${lon?.toFixed(6) ?? '0'}`
                });
            },
            (error) => {
                console.error('Error de geolocalización:', error);
                resolve({
                    latitud: 0,
                    longitud: 0,
                    direccion: 'No se pudo obtener la ubicación. Por favor, activa el GPS.',
                    coordenadas: 'No disponible'
                });
            },
            { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
        );
    });
}

async function obtenerDireccion(lat, lon) {
    try {
        const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`;
        const response = await fetch(url, { headers: { 'User-Agent': 'Emergency Contact App' } });
        if (!response?.ok) throw new Error('Error al obtener dirección');
        const data = await response.json();
        const address = data?.address ?? {};
        const partes = [];
        if (address?.road) partes.push(address.road);
        if (address?.house_number) partes.push(`#${address.house_number}`);
        if (address?.suburb || address?.neighbourhood) partes.push(address?.suburb ?? address?.neighbourhood);
        if (address?.city || address?.town || address?.village) partes.push(address?.city ?? address?.town ?? address?.village);
        if (address?.state) partes.push(address.state);
        if (address?.postcode) partes.push(`CP ${address.postcode}`);
        return partes?.length > 0 ? partes.join(', ') : data?.display_name ?? 'Dirección no disponible';
    } catch (error) {
        console.error('Error al obtener dirección:', error);
        return `Coordenadas: ${lat?.toFixed(6) ?? '0'}, ${lon?.toFixed(6) ?? '0'}`;
    }
}

function mostrarDatosEmergencia() {
    const infoNombre = document.getElementById('infoNombre');
    const infoTipoSangre = document.getElementById('infoTipoSangre');
    const infoAlergias = document.getElementById('infoAlergias');
    if (infoNombre) infoNombre.textContent = DATOS_PERSONALES?.nombre ?? 'No disponible';
    if (infoTipoSangre) infoTipoSangre.textContent = DATOS_PERSONALES?.tipoSangre ?? 'No disponible';
    if (infoAlergias) infoAlergias.textContent = DATOS_PERSONALES?.alergias ?? 'Ninguna';
    const infoHora = document.getElementById('infoHora');
    const infoDireccion = document.getElementById('infoDireccion');
    const infoCoordenadas = document.getElementById('infoCoordenadas');
    if (infoHora && horaIncidente) {
        infoHora.textContent = horaIncidente?.toLocaleString('es-MX', { dateStyle: 'full', timeStyle: 'medium' }) ?? 'No disponible';
    }
    if (infoDireccion && ubicacionActual) {
        infoDireccion.textContent = ubicacionActual?.direccion ?? 'No disponible';
    }
    if (infoCoordenadas && ubicacionActual) {
        infoCoordenadas.textContent = ubicacionActual?.coordenadas ?? 'No disponible';
    }
    cargarContactos();
}

function cargarContactos() {
    const listaContactos = document.getElementById('listaContactos');
    if (!listaContactos) return;
    listaContactos.innerHTML = '';
    const contactos = DATOS_PERSONALES?.contactos ?? [];
    contactos?.forEach((contacto, index) => {
        const card = document.createElement('div');
        card.className = 'contact-card';
        const iniciales = obtenerIniciales(contacto?.nombre ?? 'N/A');
        card.innerHTML = `
            <div class="contact-header">
                <div class="contact-avatar">${iniciales}</div>
                <div class="contact-info">
                    <h4>${contacto?.nombre ?? 'Sin nombre'}</h4>
                    <div class="contact-relation">${contacto?.relacion ?? 'Contacto'}</div>
                </div>
            </div>
            <div class="contact-details">
                <div class="contact-detail"><span>📞</span><span>${contacto?.telefono ?? 'No disponible'}</span></div>
                <div class="contact-detail"><span>💬</span><span>${contacto?.whatsapp ?? 'No disponible'}</span></div>
                <div class="contact-detail"><span>📧</span><span>${contacto?.email ?? 'No disponible'}</span></div>
            </div>
        `;
        listaContactos?.appendChild(card);
    });
}

function obtenerIniciales(nombre) {
    const palabras = (nombre ?? '')?.trim()?.split(' ') ?? [];
    if (palabras?.length >= 2) {
        return ((palabras?.[0]?.[0] ?? '') + (palabras?.[1]?.[0] ?? '')).toUpperCase();
    }
    return (palabras?.[0]?.[0] ?? 'N')?.toUpperCase();
}

function cargarNumerosEmergencia() {
    const container = document.getElementById('numerosEmergencia');
    if (!container) return;
    container.innerHTML = '';
    (NUMEROS_EMERGENCIA ?? [])?.forEach(emergencia => {
        const link = document.createElement('a');
        link.href = `tel:${emergencia?.numero ?? ''}`;
        link.className = 'emergency-number';
        link.innerHTML = `
            <span>${emergencia?.icono ?? '📞'}</span>
            <div>${emergencia?.nombre ?? 'Emergencia'}</div>
            <div>${emergencia?.numero ?? ''}</div>
        `;
        container?.appendChild(link);
    });
}

function generarMensajeEmergencia() {
    const nombre = DATOS_PERSONALES?.nombre ?? 'Desconocido';
    const tipoSangre = DATOS_PERSONALES?.tipoSangre ?? 'Desconocido';
    const alergias = DATOS_PERSONALES?.alergias ?? 'Ninguna';
    const direccion = ubicacionActual?.direccion ?? 'Ubicación desconocida';
    const coordenadas = ubicacionActual?.coordenadas ?? 'No disponible';
    const hora = horaIncidente?.toLocaleString('es-MX') ?? 'Fecha desconocida';
    return `🆘 ALERTA DE EMERGENCIA 🆘\n\n👤 Persona: ${nombre}\n🩸 Tipo de Sangre: ${tipoSangre}\n⚠️ Alergias: ${alergias}\n\n📍 Ubicación: ${direccion}\n🗺️ Coordenadas: ${coordenadas}\n⏰ Hora: ${hora}\n\n¡Por favor contactar inmediatamente!`;
}

function enviarWhatsApp() {
    const mensaje = generarMensajeEmergencia();
    const mensajeCodificado = encodeURIComponent(mensaje ?? '');
    const contactos = DATOS_PERSONALES?.contactos ?? [];
    contactos?.forEach(contacto => {
        if (contacto?.whatsapp) {
            const numero = contacto?.whatsapp?.replace(/\D/g, '') ?? '';
            const url = `https://wa.me/${numero}?text=${mensajeCodificado}`;
            window?.open(url, '_blank');
        }
    });
}

function enviarSMS() {
    const mensaje = generarMensajeEmergencia();
    const contactos = DATOS_PERSONALES?.contactos ?? [];
    const numeros = contactos?.filter(c => c?.telefono)?.map(c => c?.telefono)?.join(',') ?? '';
    if (numeros) {
        const url = `sms:${numeros}?body=${encodeURIComponent(mensaje ?? '')}`;
        window.location.href = url;
    }
}

function enviarEmail() {
    const mensaje = generarMensajeEmergencia();
    const contactos = DATOS_PERSONALES?.contactos ?? [];
    const emails = contactos?.filter(c => c?.email)?.map(c => c?.email)?.join(',') ?? '';
    if (emails) {
        const asunto = '🆘 ALERTA DE EMERGENCIA';
        const cuerpo = mensaje?.replace(/\n/g, '%0D%0A') ?? '';
        const url = `mailto:${emails}?subject=${encodeURIComponent(asunto)}&body=${cuerpo}`;
        window.location.href = url;
    }
}

function guardarEnHistorial(datos) {
    try {
        const historial = JSON.parse(localStorage?.getItem('historialEscaneos') ?? '[]');
        historial?.push(datos);
        localStorage?.setItem('historialEscaneos', JSON.stringify(historial));
    } catch (error) {
        console.error('Error al guardar en historial:', error);
    }
}

function mostrarHistorial() {
    const listaHistorial = document.getElementById('listaHistorial');
    if (!listaHistorial) return;
    mostrarPantalla('historial');
    try {
        const historial = JSON.parse(localStorage?.getItem('historialEscaneos') ?? '[]');
        if (!historial || historial?.length === 0) {
            listaHistorial.innerHTML = '<div class="no-history"><div>📊</div><p>No hay escaneos registrados</p></div>';
            return;
        }
        listaHistorial.innerHTML = '';
        historial?.reverse()?.forEach((item, index) => {
            const fecha = new Date(item?.fecha ?? Date.now());
            const itemDiv = document.createElement('div');
            itemDiv.className = 'history-item';
            itemDiv.innerHTML = `
                <div class="history-header">
                    <div class="history-number">${index + 1}</div>
                    <div class="history-date">${fecha?.toLocaleString('es-MX') ?? 'Fecha desconocida'}</div>
                </div>
                <div class="history-details">
                    <div class="history-detail"><span>📍</span><span>${item?.ubicacion?.direccion ?? 'Ubicación no disponible'}</span></div>
                    <div class="history-detail"><span>🗺️</span><span>${item?.ubicacion?.coordenadas ?? 'Coordenadas no disponibles'}</span></div>
                </div>
            `;
            listaHistorial?.appendChild(itemDiv);
        });
    } catch (error) {
        console.error('Error al mostrar historial:', error);
        listaHistorial.innerHTML = '<div class="no-history"><p>Error al cargar el historial</p></div>';
    }
}

function limpiarHistorial() {
    if (confirm('¿Estás seguro de que quieres borrar todo el historial?')) {
        localStorage?.removeItem('historialEscaneos');
        mostrarHistorial();
    }
}

if (document?.readyState === 'loading') {
    document?.addEventListener('DOMContentLoaded', init);
} else {
    init();
}