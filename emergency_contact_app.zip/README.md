# 🆘 Emergency Contact App

**Aplicación de Emergencia para Conductores de Vehículos**

Aplicación web estática diseñada para proporcionar información crítica de emergencia mediante código QR. Ideal para motociclistas, ciclistas, conductores de bicicletas eléctricas y cualquier persona que necesite compartir su información médica y de contacto en caso de emergencia.

---

## 🎯 Características Principales

✅ Botón de Emergencia Grande  
✅ Captura Automática de Ubicación GPS + dirección legible  
✅ Información Médica Crítica: Tipo de sangre, alergias, nombre  
✅ Contactos de Emergencia con teléfonos, WhatsApp y emails  
✅ Notificaciones Automáticas por WhatsApp, SMS y correo electrónico  
✅ Números de Emergencia México: 911, Cruz Roja, Bomberos, etc.  
✅ Historial de Escaneos en localStorage  
✅ 100% Offline después de cargar  
✅ Compatible con GitHub Pages  

---

## 📱 ¿Cómo Funciona?

1. Personalizas tus datos médicos y contactos en el archivo `index.html`
2. Publicas la página en GitHub Pages
3. Generas un código QR que apunte a tu página
4. Pegas el código QR en tu casco, moto, bicicleta, etc.
5. En caso de emergencia, alguien escanea el código QR
6. La app captura automáticamente la ubicación y muestra toda tu información
7. Los testigos pueden contactar a tus familiares con un solo clic

---

## 🚀 Guía de Instalación

### Paso 1: Personalizar tus Datos

1. Abre el archivo `index.html` con un editor de texto
2. Busca la sección: **"SECCIÓN DE DATOS PERSONALES - MODIFICAR AQUÍ"**
3. Modifica el objeto `DATOS_PERSONALES` con tu información:

```javascript
const DATOS_PERSONALES = {
    nombre: "TU NOMBRE COMPLETO",
    tipoSangre: "O+",
    alergias: "Penicilina, Mariscos",
    contactos: [
        {
            nombre: "Contacto 1",
            relacion: "Esposa",
            telefono: "+525512345678",
            whatsapp: "+525512345678",
            email: "email@ejemplo.com"
        }
    ]
};
```

⚠️ **IMPORTANTE**: Los números deben incluir +52 para México (sin espacios ni guiones)

### Paso 2: Crear Repositorio en GitHub

1. Ve a [GitHub](https://github.com) e inicia sesión
2. Clic en "+" → "New repository"
3. Nombre: `emergency_contact_app`
4. Marca como "Public"
5. Clic en "Create repository"

### Paso 3: Subir Archivos

1. En tu repositorio, clic en "uploading an existing file"
2. Arrastra los 4 archivos: `index.html`, `styles.css`, `script.js`, `README.md`
3. Clic en "Commit changes"

### Paso 4: Activar GitHub Pages

1. Ve a Settings → Pages
2. En "Source", selecciona "main" branch
3. Clic en "Save"
4. Tu página estará en: `https://TU-USUARIO.github.io/emergency_contact_app/`

---

## 📲 Generar Código QR

Usa cualquier generador online:

- [QR Code Generator](https://www.qr-code-generator.com/)
- [QRCode Monkey](https://www.qrcode-monkey.com/)
- [Flowcode](https://www.flowcode.com/)

1. Pega tu URL de GitHub Pages
2. Personaliza el diseño (opcional)
3. Descarga en alta calidad (PNG o SVG)
4. Imprime en tamaño mínimo 5x5 cm
5. Usa stickers impermeables

---

## 🎨 Dónde Colocar el Código QR

**Motociclistas:**
- Parte trasera del casco
- Tanque de gasolina
- Guardafangos trasero

**Ciclistas:**
- Cuadro de la bicicleta
- Casco
- Porta botellas

**Recomendaciones:**
- Tamaño mínimo: 5x5 cm
- Material impermeable
- Texto: "EMERGENCIA - ESCANEAR EN CASO DE ACCIDENTE"

---

## 🔧 Actualizar Datos

1. Ve a tu repositorio en GitHub
2. Clic en `index.html` → ✏️ Editar
3. Modifica la sección DATOS_PERSONALES
4. Clic en "Commit changes"
5. Los cambios se reflejan en 1-2 minutos

---

## ❓ Preguntas Frecuentes

**¿Es gratis?**  
Sí, completamente gratis. GitHub Pages es gratuito.

**¿Funciona sin internet?**  
Parcialmente. La app se carga una vez y funciona offline, excepto:
- Conversión de GPS a dirección (requiere conexión)
- Envío de WhatsApp/SMS/Email (requiere conexión)

**¿Mis datos están seguros?**  
Sí. La app es 100% estática sin base de datos. Tu información solo es visible para quien escanea el QR.

**¿Puedo usar un dominio personalizado?**  
Sí. GitHub Pages permite configurar dominios personalizados en Settings → Pages.

**¿Funciona en iPhone y Android?**  
Sí. Es una aplicación web responsive que funciona en cualquier navegador moderno.

---

## 🛠️ Personalización Avanzada

### Cambiar Colores

Edita `styles.css` y busca:

```css
#DC2626  /* Rojo de emergencia */
#EA580C  /* Naranja de acento */
```

### Agregar Más Números de Emergencia

En `index.html`, modifica:

```javascript
const NUMEROS_EMERGENCIA = [
    { nombre: "Emergencias", numero: "911", icono: "🚨" },
    { nombre: "Tu Seguro", numero: "55-1234-5678", icono: "🏥" }
];
```

---

## 🐛 Solución de Problemas

**La ubicación no se captura:**
- Verifica permisos de ubicación en el navegador
- iPhone: Settings → Safari → Ubicación → Permitir
- Android: Settings → Apps → Chrome → Permisos → Ubicación

**El código QR no escanea:**
- Genera un código QR de al menos 5x5 cm
- Descárgalo en alta resolución (mínimo 300 DPI)
- Prueba escanearlo antes de pegarlo

**WhatsApp no se abre:**
- Verifica que los números incluyan +52
- No uses espacios, guiones ni paréntesis
- Asegúrate de que WhatsApp esté instalado

**Los cambios no se reflejan:**
- Espera 1-2 minutos después de commit
- Recarga con Ctrl + F5 (Windows) o Cmd + Shift + R (Mac)
- Abre en modo incógnito

---

## 📄 Licencia

MIT License - Uso libre para fines personales y comerciales.

---

## ⚠️ Disclaimer

Esta aplicación es una herramienta de asistencia y NO reemplaza servicios médicos profesionales, seguros de salud o dispositivos de emergencia certificados.

---

**¡Maneja con seguridad! 🏍️🚴‍♂️**

**Hecho con ❤️ para la comunidad de conductores**